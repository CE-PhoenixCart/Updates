<div class="<?= CU_TEXT_CONTENT_WIDTH ?> cu-text">
  <div class="alert alert-info">
    <?= $text ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

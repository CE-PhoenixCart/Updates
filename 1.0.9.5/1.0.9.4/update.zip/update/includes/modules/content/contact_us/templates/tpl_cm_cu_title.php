<div class="<?= MODULE_CONTENT_CU_TITLE_CONTENT_WIDTH ?> cm-cu-title">
  <h1 class="display-4"><?= MODULE_CONTENT_CU_TITLE_PUBLIC_TITLE ?></h1>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

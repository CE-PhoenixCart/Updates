<div class="card mb-2 bm-currencies">
  <div class="card-header">
    <?= MODULE_BOXES_CURRENCIES_BOX_TITLE ?>
  </div>
  <div class="card-body">
    <?= $form, $menu->append_css('custom-select w-100') ?>
    </form>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

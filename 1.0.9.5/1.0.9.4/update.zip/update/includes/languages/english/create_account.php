<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const NAVBAR_TITLE = 'Create a Profile';

const HEADING_TITLE = 'Create a Profile';

const TEXT_ORIGIN_LOGIN = '<span class="text-danger"><strong>NOTE:</strong></span> If you have already created a Profile, you can access your details at our <a class="alert-link" href="%s"><u>sign in page</u></a>.';

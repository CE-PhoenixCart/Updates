<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const NAVBAR_TITLE_1 = 'My Profile';
const NAVBAR_TITLE_2 = 'Edit Profile';

const HEADING_TITLE = 'My Profile Information';

const SUCCESS_ACCOUNT_UPDATED = 'Your profile has been successfully updated.';

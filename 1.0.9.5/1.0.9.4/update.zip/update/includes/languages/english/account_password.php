<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const NAVBAR_TITLE_1 = 'My Profile';
const NAVBAR_TITLE_2 = 'Change Password';

const HEADING_TITLE = 'My Password';

const MY_PASSWORD_TITLE = 'My Password';

const SUCCESS_PASSWORD_UPDATED = 'Your password has been successfully updated.';
const ERROR_CURRENT_PASSWORD_NOT_MATCHING = 'Your Current Password did not match the password in our records. Please try again.';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const HEADING_TITLE = 'Sign Out';
const NAVBAR_TITLE = 'Sign Out';
const TEXT_MAIN = <<<'EOT'
You have successfully signed out of your profile.  It is now safe to leave the computer.<br><br>
Your shopping cart has been saved, the items inside it will be restored whenever you sign in to your profile.
EOT;

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const NAVBAR_TITLE = 'Specials';
const HEADING_TITLE = 'Special Offers';

const TEXT_NO_PRODUCTS = 'There are no special offers available.';

// seo
const META_SEO_TITLE = 'Special Offers Page';
const META_SEO_DESCRIPTION = 'Specials Description';

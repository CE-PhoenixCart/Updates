<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const NAVBAR_TITLE_1 = 'My Profile';
const NAVBAR_TITLE_2 = 'Newsletter Subscriptions';

const HEADING_TITLE = 'Newsletter Subscriptions';

const MY_NEWSLETTERS_GENERAL_NEWSLETTER = 'General Newsletter';
const MY_NEWSLETTERS_GENERAL_NEWSLETTER_DESCRIPTION = 'Including store news, new products, special offers, and other promotional announcements.';

const SUCCESS_NEWSLETTER_UPDATED = 'Your newsletter subscriptions have been successfully updated.';

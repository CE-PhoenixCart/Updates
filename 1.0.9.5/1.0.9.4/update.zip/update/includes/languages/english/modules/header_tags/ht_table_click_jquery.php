<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_HEADER_TAGS_TABLE_CLICK_JQUERY_TITLE = 'Table Row Click Javascript';
  const MODULE_HEADER_TAGS_TABLE_CLICK_JQUERY_DESCRIPTION = 'Add Table Row Click javascript to specified pages';
  
<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_ACCOUNT_SET_PASSWORD_TITLE = 'Set Profile Password';
  const MODULE_CONTENT_ACCOUNT_SET_PASSWORD_DESCRIPTION = 'Replace Change Password page with Set Password page if no local profile password has been set';

  const MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_LINK_TITLE = 'Set profile password.';

  const MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_1 = 'My Profile';
  const MODULE_CONTENT_ACCOUNT_SET_PASSWORD_NAVBAR_TITLE_2 = 'Set Password';

  const MODULE_CONTENT_ACCOUNT_SET_PASSWORD_HEADING_TITLE = 'Set Password';

  const MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SET_PASSWORD_TITLE = 'Set Password';

  const MODULE_CONTENT_ACCOUNT_SET_PASSWORD_SUCCESS_PASSWORD_SET = 'Your password has been successfully saved.';

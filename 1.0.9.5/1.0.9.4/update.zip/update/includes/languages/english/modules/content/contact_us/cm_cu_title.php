<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_CU_TITLE_TITLE = 'Page Heading';
  const MODULE_CONTENT_CU_TITLE_DESCRIPTION = 'Shows the Title of the Page';
  
  const MODULE_CONTENT_CU_TITLE_PUBLIC_TITLE = 'Contact Us';

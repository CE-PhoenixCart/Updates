<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_DATE_ACCOUNT_CREATED_TEXT_TITLE = 'Date Profile Created';
const MODULE_CUSTOMER_DATA_DATE_ACCOUNT_CREATED_TEXT_DESCRIPTION = 'Show the date the profile was created';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_ORDER_TOTAL_SHIPPING_TITLE = 'Delivery';
  const MODULE_ORDER_TOTAL_SHIPPING_DESCRIPTION = 'Order Delivery Cost';

  const FREE_SHIPPING_TITLE = 'Free Delivery';
  const FREE_SHIPPING_DESCRIPTION = 'Free Delivery for orders over %s';

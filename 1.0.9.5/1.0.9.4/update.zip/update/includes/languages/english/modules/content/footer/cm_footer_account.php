<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_FOOTER_ACCOUNT_TITLE = 'Profile Links';
  const MODULE_CONTENT_FOOTER_ACCOUNT_DESCRIPTION = 'Adds Profile Links to the Footer Area of your site';

  const MODULE_CONTENT_FOOTER_ACCOUNT_HEADING_TITLE = 'Customer Services';

  const MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ACCOUNT = 'My Profile';
  const MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ADDRESS_BOOK = 'My Address Book';
  const MODULE_CONTENT_FOOTER_ACCOUNT_BOX_ORDER_HISTORY = 'My Order History';
  const MODULE_CONTENT_FOOTER_ACCOUNT_BOX_LOGOFF = 'Secure Sign Out';
  const MODULE_CONTENT_FOOTER_ACCOUNT_BOX_CREATE_ACCOUNT = 'Create a Profile';
  const MODULE_CONTENT_FOOTER_ACCOUNT_BOX_LOGIN = 'Existing Customer? Sign In';


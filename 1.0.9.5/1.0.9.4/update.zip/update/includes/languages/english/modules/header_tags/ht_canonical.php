<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_HEADER_TAGS_CANONICAL_TITLE = 'Canonical Links';
  const MODULE_HEADER_TAGS_CANONICAL_DESCRIPTION = 'Add canonical links to category/product pages.  <div class="alert alert-warning">Please note that hreflang attributes are not supported in this module which will affect you if you have more than one language in your shop.<br><br>You should seek the advice of a good developer or ask in the Phoenix Forum.</div>';

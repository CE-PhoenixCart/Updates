<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_HEADER_BUTTONS_TITLE = 'Buttons';
  const MODULE_CONTENT_HEADER_BUTTONS_DESCRIPTION = 'Adds Sign In/Checkout Buttons into the Header Area of your site.';

  const MODULE_CONTENT_HEADER_BUTTONS_TITLE_CART_CONTENTS = 'Cart Contents';
  const MODULE_CONTENT_HEADER_BUTTONS_TITLE_CHECKOUT = 'Checkout';
  const MODULE_CONTENT_HEADER_BUTTONS_TITLE_LOGOFF = 'Sign Out';
  const MODULE_CONTENT_HEADER_BUTTONS_TITLE_MY_ACCOUNT = 'My Profile';

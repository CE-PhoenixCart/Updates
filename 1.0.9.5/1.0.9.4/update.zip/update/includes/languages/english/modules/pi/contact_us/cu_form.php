<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const CU_FORM_TITLE         = 'Form';
  const CU_FORM_DESCRIPTION   = 'Shows Contact Us Form on the Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';
  
  const FORM_CONTACT_US = '';
  
  const FORM_CONTACT_US_SUCCESS = '<div class="alert alert-success"><b>Thank you.</b>  Your enquiry has been sent to the Shopowner.<br><br>If you need to send us another mail, please <a class="alert-link" href="%s">click here</a>.</div>';
  
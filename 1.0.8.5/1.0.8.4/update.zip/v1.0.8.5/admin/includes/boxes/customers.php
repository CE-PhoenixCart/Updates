<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  $cl_box_groups[] = ['heading' => BOX_HEADING_CUSTOMERS, 'apps' => []];

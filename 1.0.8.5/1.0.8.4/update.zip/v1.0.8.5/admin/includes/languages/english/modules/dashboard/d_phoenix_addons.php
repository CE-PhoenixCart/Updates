<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_TITLE = 'Certified Providers';
const MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_DESCRIPTION = 'Show the latest Add-Ons for Phoenix Club members';

const MODULE_ADMIN_DASHBOARD_PHOENIX_VIEW_ALL = 'View full list';

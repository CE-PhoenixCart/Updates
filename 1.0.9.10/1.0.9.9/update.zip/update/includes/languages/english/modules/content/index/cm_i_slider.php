<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_I_SLIDER_TITLE         = 'Carousel';
  const MODULE_CONTENT_I_SLIDER_DESCRIPTION   = 'Shows a series of slides as a Carousel.<div class="alert alert-danger mt-2">Carousel content is set in Tools > Advert Manager.</div>';

  const MODULE_CONTENT_I_SLIDER_CONTROLS_PREV = 'Previous';
  const MODULE_CONTENT_I_SLIDER_CONTROLS_NEXT = 'Next';

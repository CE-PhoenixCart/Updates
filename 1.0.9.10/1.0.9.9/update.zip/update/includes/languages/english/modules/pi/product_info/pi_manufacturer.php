<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const PI_MANUFACTURER_TITLE         = 'Manufacturer Details';
  const PI_MANUFACTURER_DESCRIPTION   = 'Shows the Manufacturer Details on the Product Info Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';
  
  const PI_MANUFACTURER_HEADING = 'Manufacturer Details';
  
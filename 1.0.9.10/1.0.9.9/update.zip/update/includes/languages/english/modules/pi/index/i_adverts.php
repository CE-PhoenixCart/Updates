<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const I_ADVERTS_TITLE        = 'Adverts';
  const I_ADVERTS_DESCRIPTION  = 'Side by Side Adverts.<div class="alert alert-danger mt-2">Advert content is set in Tools > Advert Manager.</div><div class="alert alert-info">This is a child module for use with the &Pi; system, which links into the Advert Manager.</div>';

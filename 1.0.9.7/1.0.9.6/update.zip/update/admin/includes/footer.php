<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
<div class="w-100"></div>

<footer class="col mt-3 d-print-none">
  <div class="card bg-light p-0 pt-3 mb-3 card-body text-center">
    <p>CE Phoenix v<?= Versions::get('Phoenix') ?> &copy; 2000-<?= date('Y') ?> <a href="https://www.phoenixcart.org" target="_blank" rel="noreferrer">Phoenix Cart</a></p>
  </div>
</footer>

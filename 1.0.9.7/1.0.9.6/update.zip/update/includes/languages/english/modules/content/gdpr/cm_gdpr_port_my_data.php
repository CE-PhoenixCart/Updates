<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_GDPR_PORT_MY_DATA_TITLE = 'GDPR Port My Data';
  const MODULE_CONTENT_GDPR_PORT_MY_DATA_DESCRIPTION = 'This module allows the Customer to export their Data (GDPR Article 20) to a Portable File (GDPR Recital 68).';

  const MODULE_CONTENT_GDPR_PORT_MY_DATA_BUTTON_TEXT = '<i class="fas fa-file"></i> Download My Data';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_ACCOUNT_GDPR_TITLE = 'GDPR Data Overview';
  const MODULE_CONTENT_ACCOUNT_GDPR_DESCRIPTION = 'Adds a Link to the Profile Data Overview Page.';
  
  const MODULE_CONTENT_ACCOUNT_GDPR_LINK_TITLE = 'Profile Data Overview';
  const MODULE_CONTENT_ACCOUNT_GDPR_SUB_TITLE = 'View All Data';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_GDPR_CART_TITLE = 'GDPR Cart';
  const MODULE_CONTENT_GDPR_CART_DESCRIPTION = 'This module shows what the customer has in their Live Cart.';

  const MODULE_CONTENT_GDPR_CART_PUBLIC_TITLE = 'In Your Cart';
  const MODULE_CONTENT_GDPR_CART_NUM_PRODUCTS = 'Your Live Cart contains<br><span class="h1">%s</span><br>Item(s)';

  const MODULE_CONTENT_GDPR_CART_EACH = '%s x %s';

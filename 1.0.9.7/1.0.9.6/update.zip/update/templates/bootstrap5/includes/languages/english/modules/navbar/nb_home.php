<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_NAVBAR_HOME_TITLE = 'Home';
  const MODULE_NAVBAR_HOME_DESCRIPTION = 'Show Home Link in Navbar. <div class="alert alert-warning">If you wish to have a Home button permanently displayed (even when the rest of the Menu is collapsed, eg in XS viewport) you could use the Brand module instead.</div>';

  const MODULE_NAVBAR_HOME_PUBLIC_TEXT = '<i title="Home" class="fas fa-home fa-fw fa-xl"></i><span class="d-inline d-sm-none"> Home</span>';

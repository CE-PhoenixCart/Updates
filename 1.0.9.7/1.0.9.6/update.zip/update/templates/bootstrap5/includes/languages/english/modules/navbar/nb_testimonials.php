<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_NAVBAR_TESTIMONIALS_TITLE = 'Testimonials';
  const MODULE_NAVBAR_TESTIMONIALS_DESCRIPTION = 'Show Testimonials Link in Navbar.';

  const MODULE_NAVBAR_TESTIMONIALS_PUBLIC_TEXT = '<i title="Testimonials" class="fas fa-pen-to-square fa-fw fa-xl"></i><span class="d-inline d-sm-none d-md-inline"> Testimonials</span>';

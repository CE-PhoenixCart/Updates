<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

const IS_PRODUCT_SHOW_PRICE = '%s';
const IS_PRODUCT_SHOW_PRICE_SPECIAL = '<del>%s</del> <span class="text-danger">%s</span>';
const IS_PRODUCT_BUTTON_BUY = '<i class="fas fa-shopping-cart" title="Add To Cart"></i>';
const IS_PRODUCT_BUTTON_VIEW = '<i class="fas fa-eye" title="View Product"></i>';

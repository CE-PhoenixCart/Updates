<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_NAVBAR_CURRENCIES_TITLE = 'Currencies';
  const MODULE_NAVBAR_CURRENCIES_DESCRIPTION = 'Show Currencies in Navbar. <div class="alert alert-warning">If you have just one Currency in your shop, there is no point installing this module.</div>';

  const MODULE_NAVBAR_CURRENCIES_SELECTED_CURRENCY = '<i title="Selected Currency: %1$s" class="fas fa-money-bill-1-wave fa-fw fa-xl"></i><span class="d-inline d-sm-none d-md-inline"> %1$s</span>';

<button type="button" class="navbar-toggler nb-hamburger-button" data-bs-toggle="offcanvas" data-bs-target="#collapseCoreNav" aria-controls="collapseCoreNav" aria-expanded="false" aria-label="<?= MODULE_NAVBAR_HAMBURGER_BUTTON_PUBLIC_SCREENREADER_TEXT ?>">
  <?= MODULE_NAVBAR_HAMBURGER_BUTTON_PUBLIC_BUTTON_TEXT ?>
</button>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

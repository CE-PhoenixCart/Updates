<div class="<?= MODULE_CONTENT_CS_CONTINUE_BUTTON_CONTENT_WIDTH ?> cm-cs-continue-button">
  <div class="d-grid">
    <?= new Button(MODULE_CONTENT_CS_CONTINUE_BUTTON_TEXT, 'fas fa-thumbs-up', 'btn-success btn-lg') ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

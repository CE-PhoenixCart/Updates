<div class="<?= MODULE_CONTENT_GDPR_INTRO_CONTENT_WIDTH ?> cm-gdpr-intro">
  <div class="alert alert-info">
    <?= sprintf(MODULE_CONTENT_GDPR_INTRO_PUBLIC_TEXT, $GLOBALS['Linker']->build('account.php')) ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

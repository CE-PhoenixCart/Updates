<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>
  
  
  <div class="form-floating mb-2">
    <?= $input ?>
    <label for="<?= $input_id ?>"><?= $label_text ?></label>
  </div>

  

  
  

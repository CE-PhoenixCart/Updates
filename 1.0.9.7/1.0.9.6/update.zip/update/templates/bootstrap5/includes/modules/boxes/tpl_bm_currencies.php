<div class="card mt-2 bm-currencies">
  <div class="card-header">
    <?= MODULE_BOXES_CURRENCIES_BOX_TITLE ?>
  </div>
  <div class="card-body">
    <?= $form, $menu->append_css('form-select') ?>
    </form>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

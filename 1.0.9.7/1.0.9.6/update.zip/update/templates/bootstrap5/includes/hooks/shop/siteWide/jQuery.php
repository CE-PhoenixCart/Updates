<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

class hook_shop_siteWide_jQuery {

  public function listen_injectAfterFooter() {
    // jQuery is not needed in Bootstrap 5

    return null;
  }

}

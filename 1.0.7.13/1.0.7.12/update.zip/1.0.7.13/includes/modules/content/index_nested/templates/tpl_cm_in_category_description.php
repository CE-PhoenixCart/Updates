<div class="col-sm-<?= (int)MODULE_CONTENT_IN_CATEGORY_DESCRIPTION_CONTENT_WIDTH ?> cm-in-category-description">
  <div class="card mb-2 card-body">
    <?= $category_description ?>
  </div>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2021 osCommerce

  Released under the GNU General Public License
*/
?>

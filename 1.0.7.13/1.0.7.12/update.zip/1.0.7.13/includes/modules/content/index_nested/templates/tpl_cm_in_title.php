<div class="col-sm-<?= (int)MODULE_CONTENT_IN_TITLE_CONTENT_WIDTH ?> cm-in-title">
  <h1 class="display-4"><?= sprintf(MODULE_CONTENT_IN_TITLE_PUBLIC_TITLE, $category_name) ?></h1>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2021 osCommerce

  Released under the GNU General Public License
*/
?>

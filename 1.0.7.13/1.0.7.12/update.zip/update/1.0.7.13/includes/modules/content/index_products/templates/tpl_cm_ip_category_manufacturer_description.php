<div class="col-sm-<?= (int)MODULE_CONTENT_IP_CATEGORY_DESCRIPTION_CONTENT_WIDTH ?> cm-ip-category-manufacturer-description">
  <div class="card mb-2 card-body">
    <?= $cm_description ?>
  </div>
</div>

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2021 osCommerce

  Released under the GNU General Public License
*/
?>

<div class="<?= MODULE_CONTENT_IP_CATEGORY_DESCRIPTION_CONTENT_WIDTH ?> cm-ip-category-manufacturer-description">
  <div class="card">
    <div class="card-body">
      <?= $cm_description ?>
    </div>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

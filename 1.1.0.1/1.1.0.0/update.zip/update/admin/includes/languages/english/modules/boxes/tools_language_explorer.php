<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2025 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULES_ADMIN_MENU_TOOLS_LANGUAGE_EXPLORER = 'Language Explorer';

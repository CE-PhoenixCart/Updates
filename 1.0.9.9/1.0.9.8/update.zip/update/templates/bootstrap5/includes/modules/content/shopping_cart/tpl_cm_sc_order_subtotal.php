<div class="<?= MODULE_CONTENT_SC_ORDER_SUBTOTAL_CONTENT_WIDTH ?> cm-sc-order-subtotal">
  <p class="text-end fs-4 fw-semibold me-3"><?= $cart_total ?></p>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

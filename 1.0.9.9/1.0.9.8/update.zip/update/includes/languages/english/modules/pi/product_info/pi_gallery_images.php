<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const PI_GALLERY_IMAGES_TITLE       = 'Gallery Images';
  const PI_GALLERY_IMAGES_DESCRIPTION = 'Shows the extra Product Image(s) on the product_info Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';
  
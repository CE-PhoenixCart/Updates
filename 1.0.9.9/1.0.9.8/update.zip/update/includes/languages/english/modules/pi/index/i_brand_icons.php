<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const I_BRAND_ICONS_TITLE = 'Brand Icons';
  const I_BRAND_ICONS_DESCRIPTION = 'Display Brand Icons with a link to the relevant brand page.<div class="alert alert-info">This is a child module for use with the &Pi; system.</div>';
  
  const I_BRAND_ICONS_HEADING     = 'Popular Brands';
  
  const I_BRAND_ICONS_PREV = 'Previous';
  const I_BRAND_ICONS_NEXT = 'Next';
  
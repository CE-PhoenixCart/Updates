<div class="<?= PI_DATE_AVAILABLE_CONTENT_WIDTH ?> pi-date-available">
  <div class="alert alert-info d-flex justify-content-between align-items-center">
    <?= sprintf(PI_DATE_AVAILABLE_TEXT, $date) ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

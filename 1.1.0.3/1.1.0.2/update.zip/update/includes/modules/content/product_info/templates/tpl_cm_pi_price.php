<div class="<?= MODULE_CONTENT_PI_PRICE_CONTENT_WIDTH ?> cm-pi-price">
  <h2 class="display-4"><?= $price ?></h2>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

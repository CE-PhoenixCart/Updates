<div class="col-sm-<?= $content_width ?> cm-cs-continue-button my-2">
  <?= new Button(MODULE_CONTENT_CS_CONTINUE_BUTTON_TEXT, 'fas fa-thumbs-up', 'btn-success btn-block btn-lg') ?>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_ACTION_RECORDER_CONTACT_US_EMAIL_TITLE = 'Contact Us';
  const MODULE_ACTION_RECORDER_CONTACT_US_EMAIL_DESCRIPTION = 'Record usage of the Contact Us feature.';

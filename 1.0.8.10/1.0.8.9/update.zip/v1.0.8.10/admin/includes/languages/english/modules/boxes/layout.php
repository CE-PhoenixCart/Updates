<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('BOX_HEADING_LAYOUT', '<i data-content="Layout Modules" data-toggle="popover" data-placement="right" class="fas fa-puzzle-piece fa-fw mr-1"></i><span class="d-inline d-md-none">Layout Modules</span>');

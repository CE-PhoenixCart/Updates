<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Hooks');

define('TABLE_HEADING_LOCATION', '<span class="text-uppercase">%s</span>');
define('TABLE_HEADING_GROUP', 'Group');
define('TABLE_HEADING_FILE', 'File');
define('TABLE_HEADING_METHOD', 'Method');
define('TABLE_HEADING_VERSION', 'Version');

define('TEXT_HOOKS_DIRECTORY', 'Hooks Directory:');

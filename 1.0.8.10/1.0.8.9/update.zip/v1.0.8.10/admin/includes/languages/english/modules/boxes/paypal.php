<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULES_ADMIN_MENU_PAYPAL_HEADING', '<i data-content="Paypal" data-toggle="popover" data-placement="left" class="fab fa-paypal fa-fw mr-1"></i><span class="d-inline d-md-none">Paypal</span>');

  define('MODULES_ADMIN_MENU_PAYPAL_BALANCE', 'Balance');
  define('MODULES_ADMIN_MENU_PAYPAL_CONFIGURE', 'Configure');
  define('MODULES_ADMIN_MENU_PAYPAL_LOG', 'Log');
  define('MODULES_ADMIN_MENU_PAYPAL_MANAGE_CREDENTIALS', 'Credentials');
  define('MODULES_ADMIN_MENU_PAYPAL_START', 'Start');

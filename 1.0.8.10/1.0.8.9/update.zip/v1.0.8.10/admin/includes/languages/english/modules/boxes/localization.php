<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('BOX_HEADING_LOCALIZATION', '<i data-content="Localization" data-toggle="popover" data-placement="right" class="fas fa-language fa-fw mr-1"></i><span class="d-inline d-md-none">Localization</span>');

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('BOX_HEADING_LOCATION_AND_TAXES', '<i data-content="Locations & Taxes" data-toggle="popover" data-placement="right" class="fas fa-comments-dollar fa-fw mr-1"></i><span class="d-inline d-md-none">Locations & Taxes</span>');

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const WARNING_SESSION_DIRECTORY_NON_EXISTENT = 'The sessions directory does not exist:  "%s". Sessions will not work until this directory is created.';
const WARNING_SESSION_DIRECTORY_NOT_WRITEABLE = 'I am not able to write to the sessions directory:  "%s". Sessions will not work until the right user permissions are set.';

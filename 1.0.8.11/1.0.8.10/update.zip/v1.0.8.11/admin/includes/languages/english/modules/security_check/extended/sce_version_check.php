<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2013 osCommerce

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_TITLE', 'Version Check');
define('MODULE_SECURITY_CHECK_EXTENDED_VERSION_CHECK_ERROR', 'A new version check was performed more than 30 days ago. Please perform the check to see if a new version is available.');
?>

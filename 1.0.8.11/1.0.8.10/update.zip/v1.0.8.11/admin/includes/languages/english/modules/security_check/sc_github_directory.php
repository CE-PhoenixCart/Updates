<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

define('MODULE_SECURITY_CHECK_GITHUB_TITLE', 'Github Directory');
define('MODULE_SECURITY_CHECK_GITHUB_DIRECTORY_EXISTS', 'Github directory exists at: ' . DIR_FS_CATALOG . '.github. You should delete this directory.');

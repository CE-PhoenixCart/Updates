<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_TITLE = 'Web File Access admin/backups/';
const MODULE_SECURITY_CHECK_EXTENDED_ADMIN_BACKUP_FILE_HTTP_200 = <<<'EOT'
Backup files in %s can be accessed and downloaded directly - please disable public access to this directory in your web server configuration.'
EOT;

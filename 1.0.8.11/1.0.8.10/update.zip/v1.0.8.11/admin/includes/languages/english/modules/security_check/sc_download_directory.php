<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const WARNING_DOWNLOAD_DIRECTORY_NON_EXISTENT = 'The downloadable products directory does not exist:  [%s]. Downloadable products will not work until this directory is valid.';

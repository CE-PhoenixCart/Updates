<div class="col-sm-<?= (int)MODULE_CONTENT_CAS_CONTINUE_BUTTON_CONTENT_WIDTH ?> cm-cas-continue-button">
  <?= new Button(MODULE_CONTENT_CAS_CONTINUE_BUTTON_TEXT, 'fas fa-angle-right', 'btn-success btn-block btn-lg', [], $origin_href) ?>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

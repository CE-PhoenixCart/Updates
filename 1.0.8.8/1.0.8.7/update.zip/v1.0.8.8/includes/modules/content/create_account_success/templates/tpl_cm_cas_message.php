<div class="col-sm-<?= (int)MODULE_CONTENT_CAS_MESSAGE_CONTENT_WIDTH ?> cm-cas-message">
  <div class="alert alert-success" role="alert">
    <?= sprintf(MODULE_CONTENT_CAS_MESSAGE_PUBLIC_TITLE, $contact_us_href, $account_href) ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<div class="col-sm-<?= MODULE_CONTENT_CUSTOMER_GREETING_CONTENT_WIDTH ?> cm-i-customer-greeting">
  <div class="alert alert-info" role="alert">
    <?= $customer_greeting ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

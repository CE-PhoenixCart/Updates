<div class="col-sm-<?= (int)MODULE_CONTENT_HEADER_LOGO_CONTENT_WIDTH ?> cm-header-logo">
  <a href="<?= $GLOBALS['Linker']->build('index.php') ?>"><?= new Image('images/' . STORE_LOGO, [], htmlspecialchars(STORE_NAME)) ?></a>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>


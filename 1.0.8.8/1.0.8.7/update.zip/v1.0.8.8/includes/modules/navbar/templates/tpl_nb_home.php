<li class="nav-item nb-home">
  <?= '<a class="nav-link" href="' . $GLOBALS['Linker']->build('index.php') . '">' . MODULE_NAVBAR_HOME_PUBLIC_TEXT . '</a>' ?>
</li>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

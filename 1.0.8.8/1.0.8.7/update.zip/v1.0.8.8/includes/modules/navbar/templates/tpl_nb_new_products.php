<li class="nav-item nb-new-products">
  <?= '<a class="nav-link" href="' . $GLOBALS['Linker']->build('products_new.php') . '">' . MODULE_NAVBAR_NEW_PRODUCTS_PUBLIC_TEXT . '</a>' ?>
</li>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>
  <div class="form-group row">
    <label for="<?= $input_id ?>" class="col-form-label col-sm-3 text-left text-sm-right"><?= $label_text ?></label>
    <div class="col-sm-9"><?= $input ?></div>
  </div>

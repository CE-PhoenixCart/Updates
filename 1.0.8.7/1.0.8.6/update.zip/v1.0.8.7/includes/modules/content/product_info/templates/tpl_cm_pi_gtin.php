<div class="col-sm-<?= (int)MODULE_CONTENT_PRODUCT_INFO_GTIN_CONTENT_WIDTH ?> cm-pi-gtin">
  <ul class="list-group">
    <li class="list-group-item d-flex justify-content-between align-items-center">
      <?= sprintf(MODULE_CONTENT_PRODUCT_INFO_GTIN_PUBLIC_TITLE, $gtin) ?>
    </li>
  </ul>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<div class="col-sm-<?= (int)PI_MODEL_CONTENT_WIDTH ?> pi-model mb-2">
  <ul class="list-group">
    <li class="list-group-item d-flex justify-content-between align-items-center">
      <?= sprintf(PI_MODEL_DISPLAY_MODEL, $products_model) ?>
    </li>
  </ul>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

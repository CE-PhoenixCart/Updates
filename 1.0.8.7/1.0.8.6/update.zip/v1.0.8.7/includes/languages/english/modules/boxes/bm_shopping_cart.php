<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_BOXES_SHOPPING_CART_TITLE = 'Shopping Cart';
  const MODULE_BOXES_SHOPPING_CART_DESCRIPTION = 'Show shopping cart contents';

  const MODULE_BOXES_SHOPPING_CART_BOX_TITLE = 'Shopping Cart';
  const MODULE_BOXES_SHOPPING_CART_BOX_CART_EMPTY = '0 items';
  const MODULE_BOXES_SHOPPING_CART_BOX_ITEM_QUANTITY = '%d x %s';

  const MODULE_BOXES_SHOPPING_CART_BOX_CART_TOTAL = '<span class="cart-value">%s</span>';

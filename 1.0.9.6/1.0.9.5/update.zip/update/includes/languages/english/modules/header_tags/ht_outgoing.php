<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_HEADER_TAGS_O_TITLE = 'Queued E-mails';
  const MODULE_HEADER_TAGS_O_DESCRIPTION = 'Amends the Outgoing E-mail Queue by adding and removing e-mails.';
  
  const MODULE_HEADER_TAGS_O_PAGES = '<b>Page(s)</b><br>';
  const MODULE_HEADER_TAGS_O_PAGES_LIVE = '%s<br>';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2025 Phoenix Cart

  Released under the GNU General Public License
*/

  const PI_URL_TITLE         = 'URL';
  const PI_URL_DESCRIPTION   = 'Displays the Products URL (if set) on the Product Info Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';

  const PI_URL_DISPLAY_URL = 'Read more about this product <a class="stretched-link link-body-emphasis" target="_blank" href="%s"><i class="fas fa-external-link-alt fa-xs"></i></a>';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_FOOTER_EXTRA_ICONS_TITLE = 'Footer Icons';
  const MODULE_CONTENT_FOOTER_EXTRA_ICONS_DESCRIPTION = <<<'EOT'
Adds FontAwesome Icons to the Footer Area of your site.<div class="alert alert-info">Available Icons are shown here: https://fontawesome.com/v5/search?o=r&ic=free&c=payments-shopping</div>
EOT;

  const MODULE_CONTENT_FOOTER_EXTRA_ICONS_TEXT = '';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const GET_HELP_LINK = 'https://phoenixcart.org/phoenixcartwiki/index.php?title=Admin_Dashboard';
const HEADING_TITLE_LANGUAGE = 'Language:';

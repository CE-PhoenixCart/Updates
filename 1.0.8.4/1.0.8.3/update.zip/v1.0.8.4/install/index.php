<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  $page_contents = basename(__FILE__);

  require 'includes/application.php';
  require 'templates/main_page.php';
?>

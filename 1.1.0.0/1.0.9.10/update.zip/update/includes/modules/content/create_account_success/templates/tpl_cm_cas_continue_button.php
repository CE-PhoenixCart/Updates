<div class="<?= MODULE_CONTENT_CAS_CONTINUE_BUTTON_CONTENT_WIDTH ?> cm-cas-continue-button">
  <div class="d-grid">
    <?= new Button(MODULE_CONTENT_CAS_CONTINUE_BUTTON_TEXT, 'fas fa-angle-right', 'btn-success btn-lg', [], $origin_href) ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<div class="<?= MODULE_CONTENT_GDPR_PORT_MY_DATA_CONTENT_WIDTH ?> cm-gdpr-port-my-data">
  <div class="d-grid">
    <a role="button" class="btn btn-info btn-lg" href="<?= $GLOBALS['Linker']->build('gdpr.php', ['action' => 'gdpr_data']) ?>"><?= MODULE_CONTENT_GDPR_PORT_MY_DATA_BUTTON_TEXT ?></a>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

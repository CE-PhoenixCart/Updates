<div class="<?= MODULE_CONTENT_FOOTER_TEXT_CONTENT_WIDTH ?> cm-footer-text">
  <p class="fs-4 fw-semibold mb-1"><?= MODULE_CONTENT_FOOTER_TEXT_HEADING_TITLE ?></p>
  
  <?= MODULE_CONTENT_FOOTER_TEXT_TEXT ?>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

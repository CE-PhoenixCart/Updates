<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_NAVBAR_LANGUAGES_TITLE = 'Languages';
  const MODULE_NAVBAR_LANGUAGES_DESCRIPTION = 'Show Languages in Navbar. <div class="alert alert-warning">If you have just one Language in your shop, there is no point installing this module.</div>';

  const MODULE_NAVBAR_LANGUAGES_SELECTED_LANGUAGE = '<i title="Selected Language: English" class="fas fa-language fa-fw fa-xl"></i><span class="d-inline d-sm-none d-md-inline"> English</span>';

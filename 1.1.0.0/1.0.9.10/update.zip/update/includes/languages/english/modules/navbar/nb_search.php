<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_NAVBAR_SEARCH_TITLE = 'Search';
  const MODULE_NAVBAR_SEARCH_DESCRIPTION = 'Show Search Icon in Navbar. <div class="alert alert-warning">This invokes a Modal Popup window showing a search box.</div>';

  const MODULE_NAVBAR_SEARCH_PUBLIC_TEXT = '<i title="Search our site" class="fas fa-magnifying-glass fa-fw fa-xl"></i><span class="ps-1">Product Search</span>';
  
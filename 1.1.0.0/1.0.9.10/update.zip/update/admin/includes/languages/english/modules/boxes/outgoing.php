<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_OUTGOING_EMAIL = '<i title="Queued E-mails" class="fas fa-clock fa-fw me-1"></i><span title="Queued E-mails" class="d-xl-none">Queued E-mails</span>'; 
  
<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_LOCALIZATION = '<i title="Localization" class="fas fa-language fa-fw me-1"></i><span title="Localization" class="d-xl-none">Localization</span>';

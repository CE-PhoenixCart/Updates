<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_CUSTOMERS = '<i title="Customers" class="fas fa-users fa-fw me-1"></i><span title="Customers" class="d-xl-none">Customers</span>';

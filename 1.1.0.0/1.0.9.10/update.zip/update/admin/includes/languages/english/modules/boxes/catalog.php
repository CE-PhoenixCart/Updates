<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_CATALOG = '<i title="Catalog" class="fas fa-cart-plus fa-fw me-1"></i><span title="Catalog" class="d-xl-none">Catalog</span>';

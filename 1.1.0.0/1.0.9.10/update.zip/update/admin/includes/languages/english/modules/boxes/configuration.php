<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_CONFIGURATION = '<i title="Configuration" class="fas fa-cogs fa-fw me-1"></i><span title="Configuration" class="d-xl-none">Configuration</span>';

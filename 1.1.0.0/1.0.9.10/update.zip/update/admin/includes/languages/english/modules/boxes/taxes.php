<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_LOCATION_AND_TAXES = '<i title="Locations & Taxes" class="fas fa-comments-dollar fa-fw me-1"></i><span title="Locations & Taxes" class="d-xl-none">Locations & Taxes</span>';

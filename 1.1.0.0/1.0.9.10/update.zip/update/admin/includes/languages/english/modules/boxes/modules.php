<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_MODULES = '<i title="Modules" class="fas fa-folder-open fa-fw me-1"></i><span title="Modules" class="d-xl-none">Modules</span>';

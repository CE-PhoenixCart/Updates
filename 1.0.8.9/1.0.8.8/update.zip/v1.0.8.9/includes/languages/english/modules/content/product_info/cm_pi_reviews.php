<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PRODUCT_INFO_REVIEWS_TITLE       = 'Product Reviews';
  const MODULE_CONTENT_PRODUCT_INFO_REVIEWS_DESCRIPTION = 'Show reviews on the product info page.';

  const MODULE_CONTENT_PRODUCT_INFO_REVIEWS_TEXT_TITLE = 'What our customers say...';
  const MODULE_CONTENT_PRODUCT_INFO_REVIEWS_TEXT_RATED  = 'Rated %1$s by <cite title="%2$s">%2$s</cite>';

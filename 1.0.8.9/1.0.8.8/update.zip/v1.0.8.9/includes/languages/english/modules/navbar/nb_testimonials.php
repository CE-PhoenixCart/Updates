<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_TESTIMONIALS_TITLE', 'Testimonials');
  define('MODULE_NAVBAR_TESTIMONIALS_DESCRIPTION', 'Show Testimonials Link in Navbar.');

  define('MODULE_NAVBAR_TESTIMONIALS_PUBLIC_TEXT', '<i title="Testimonials" class="fas fa-fw fa-user-edit"></i><span class="d-inline d-sm-none d-md-inline"> Testimonials</span>');

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const PI_GALLERY_TITLE       = 'Gallery';
  const PI_GALLERY_DESCRIPTION = 'Shows the Products Image(s) on the product_info Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';

  const PI_GALLERY_ALBUM_NAME = 'Album for %s';
  const PI_GALLERY_ALBUM_CLOSE = 'Close';


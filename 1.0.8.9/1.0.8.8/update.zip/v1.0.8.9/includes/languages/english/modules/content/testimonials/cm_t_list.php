<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_TESTIMONIALS_LIST_TITLE', 'List of Testimonials');
  define('MODULE_CONTENT_TESTIMONIALS_LIST_DESCRIPTION', 'Shows a list of Testimonials.');

  define('MODULE_CONTENT_TESTIMONIALS_LIST_NO_TESTIMONIALS', 'There are no Testimonials to show...');

  define('MODULE_CONTENT_TESTIMONIALS_LIST_WRITERS_NAME_DATE', 'Written by %s on %s.');

  define('MODULE_CONTENT_TESTIMONIALS_DISPLAY_NUMBER', 'Displaying <b>%s</b> to <b>%s</b> (of <b>%s</b> Testimonials)');

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PI_MODULAR_TITLE        = '&pi; Modular product_info';
  const MODULE_CONTENT_PI_MODULAR_DESCRIPTION  = 'Now you can more easily layout your Product Page.<div class="alert alert-warning">This module requires the use of &pi; child modules.  Any slots that have no child modules...will not display!</div>';

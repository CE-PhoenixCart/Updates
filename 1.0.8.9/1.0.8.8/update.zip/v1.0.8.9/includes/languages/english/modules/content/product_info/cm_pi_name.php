<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PI_NAME_TITLE        = 'Name';
  const MODULE_CONTENT_PI_NAME_DESCRIPTION  = 'Shows the Products Name on the product_info Page.';

  const MODULE_CONTENT_PI_NAME_DISPLAY_NAME = '%s';

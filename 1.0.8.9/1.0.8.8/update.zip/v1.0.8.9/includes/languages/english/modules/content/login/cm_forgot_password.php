<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_FORGOT_PASSWORD_TITLE', 'Forgot Password');
  define('MODULE_CONTENT_FORGOT_PASSWORD_DESCRIPTION', 'Show a link to allow customer to reset password on the login page');

  define('MODULE_CONTENT_FORGOT_PASSWORD_INTRO_TEXT', 'Did you forget your Password?  No problem!');
  define('MODULE_CONTENT_FORGOT_PASSWORD_BUTTON_TEXT', 'Reset Password');

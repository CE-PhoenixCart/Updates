<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const PI_IMG_DISCLAIMER_TITLE       = 'Image Disclaimer';
  const PI_IMG_DISCLAIMER_DESCRIPTION = 'Shows Image Disclaimer on the Product Info Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';

  const PI_IMG_DISCLAIMER_TEXT = 'Product may vary slightly from image representation.';

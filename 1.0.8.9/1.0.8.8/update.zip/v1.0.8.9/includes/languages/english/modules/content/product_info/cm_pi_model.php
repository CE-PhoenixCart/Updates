<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PI_MODEL_TITLE         = 'Model';
  const MODULE_CONTENT_PI_MODEL_DESCRIPTION   = 'Shows the Products Model on the Product Info Page.';

  const MODULE_CONTENT_PI_MODEL_DISPLAY_MODEL = 'Model:<span class="badge badge-primary badge-pill">%s</span>';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const PI_BUY_TITLE       = 'Buy Button';
  const PI_BUY_DESCRIPTION = 'Shows the Buy Button on the product_info Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';

  const PI_BUY_BUTTON_TEXT = 'Add To Cart';

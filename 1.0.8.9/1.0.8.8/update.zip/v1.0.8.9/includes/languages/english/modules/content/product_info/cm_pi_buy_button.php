<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_PI_BUY_TITLE       = 'Buy Button';
  const MODULE_CONTENT_PI_BUY_DESCRIPTION = 'Shows the Buy Button on the product_info Page.';

  const MODULE_CONTENT_PI_BUY_BUTTON_TEXT = 'Add To Cart';

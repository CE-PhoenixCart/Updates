<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_CONTENT_HEADER_BUTTONS_TITLE', 'Buttons');
  define('MODULE_CONTENT_HEADER_BUTTONS_DESCRIPTION', 'Adds Login/Checkout Buttons into the Header Area of your site.');

  define('MODULE_CONTENT_HEADER_BUTTONS_TITLE_CART_CONTENTS', 'Cart Contents');
  define('MODULE_CONTENT_HEADER_BUTTONS_TITLE_CHECKOUT', 'Checkout');
  define('MODULE_CONTENT_HEADER_BUTTONS_TITLE_LOGOFF', 'Log Off');
  define('MODULE_CONTENT_HEADER_BUTTONS_TITLE_MY_ACCOUNT', 'My Account');

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  define('MODULE_NAVBAR_HOME_TITLE', 'Home');
  define('MODULE_NAVBAR_HOME_DESCRIPTION', 'Show Home Link in Navbar. <div class="alert alert-warning">If you wish to have a Home button permanently displayed (even when the rest of the Menu is collapsed, eg in XS viewport) you could use the Brand module instead.</div>');

  define('MODULE_NAVBAR_HOME_PUBLIC_TEXT', '<i title="Home" class="fas fa-home"></i><span class="d-inline d-sm-none d-md-inline"> Home</span>');

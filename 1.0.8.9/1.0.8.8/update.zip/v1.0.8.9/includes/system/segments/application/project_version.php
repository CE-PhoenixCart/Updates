<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

// define the project version --- obsolete, now retrieved with Versions::get()
  const PROJECT_VERSION = 'CE Phoenix Cart';

<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2014 osCommerce

  Released under the GNU General Public License
*/

  class OSCOM_PayPal_Cfg_proxy {
    var $default = '';
    var $title;
    var $description;
    var $sort_order = 400;

    function __construct() {
      global $OSCOM_PayPal;

      $this->title = $OSCOM_PayPal->getDef('cfg_proxy_title');
      $this->description = $OSCOM_PayPal->getDef('cfg_proxy_desc');
    }

    function getSetField() {
      $input = new Input('proxy', ['value' => OSCOM_APP_PAYPAL_PROXY, 'id' => 'inputProxy']);

      $result = <<<EOT
<h5>{$this->title}</h5>
<p>{$this->description}  </p>

<div>{$input}</div>
EOT;

      return $result;
    }
  }

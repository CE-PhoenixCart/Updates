<li class="nav-item nb-home">
  <?= '<a class="nav-link" href="' . tep_href_link('index.php') . '">' . MODULE_NAVBAR_HOME_PUBLIC_TEXT . '</a>' ?>
</li>

<?php
/*
 $Id$

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2020 osCommerce

 Released under the GNU General Public License
*/
?>

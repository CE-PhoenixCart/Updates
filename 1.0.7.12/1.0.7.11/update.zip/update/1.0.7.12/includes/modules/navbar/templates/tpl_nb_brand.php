<?php
/*
 $Id$

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2020 osCommerce

 Released under the GNU General Public License
*/

echo '<a class="navbar-brand nb-brand" href="' . tep_href_link('index.php') . '">' . MODULE_NAVBAR_BRAND_PUBLIC_TEXT . '</a>';

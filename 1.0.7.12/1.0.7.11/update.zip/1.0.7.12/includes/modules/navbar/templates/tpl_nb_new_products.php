<li class="nav-item nb-new-products">
  <?= '<a class="nav-link" href="' . tep_href_link('products_new.php') . '">' . MODULE_NAVBAR_NEW_PRODUCTS_PUBLIC_TEXT . '</a>' ?>
</li>

<?php
/*
 $Id$

 osCommerce, Open Source E-Commerce Solutions
 http://www.oscommerce.com

 Copyright (c) 2020 osCommerce

 Released under the GNU General Public License
*/
?>

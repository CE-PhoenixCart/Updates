<?php
/*
  $Id$

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2020 osCommerce

  Released under the GNU General Public License
*/

const NAVBAR_TITLE = 'Privacy Notice';

/*
Define the Title and Text of this page using the Info Pages Manager.
Admin > Tools > Info Pages
*/

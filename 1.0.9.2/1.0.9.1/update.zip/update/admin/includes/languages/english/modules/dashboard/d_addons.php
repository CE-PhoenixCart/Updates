<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_ADDONS_TITLE = 'Latest Addons';
const MODULE_ADMIN_DASHBOARD_ADDONS_DESCRIPTION = 'Show the latest Addons from Addons Library';

const MODULE_ADMIN_DASHBOARD_ADDONS_AUTHOR = 'Author';
const MODULE_ADMIN_DASHBOARD_ADDONS_UPDATED = 'Updated';
const MODULE_ADMIN_DASHBOARD_ADDONS_VIEW_ALL = 'Go to Addons Library';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_CATALOG = '<i data-content="Catalog" data-toggle="popover" data-placement="right" class="fas fa-cart-plus fa-fw mr-1"></i><span class="d-inline d-md-none">Catalog</span>';

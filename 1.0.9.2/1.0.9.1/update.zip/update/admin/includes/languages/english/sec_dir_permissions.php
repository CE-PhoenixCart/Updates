<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const HEADING_TITLE = 'Security Directory Permissions';

const TABLE_HEADING_DIRECTORIES = 'Directories';
const TABLE_HEADING_RECOMMENDED = 'Recommended';

const TEXT_DIRECTORY = 'Directory:  %s';

const GET_HELP_LINK = 'https://phoenixcart.org/phoenixcartwiki/index.php?title=Security_Directory_Permissions';

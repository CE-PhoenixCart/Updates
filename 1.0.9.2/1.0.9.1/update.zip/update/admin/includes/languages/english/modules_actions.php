<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const HEADING_TITLE          = 'Actions';

const TABLE_HEADING_FILE     = 'File';
const TABLE_HEADING_ACTION   = 'Action';
const TABLE_HEADING_CLASS    = 'Class';
const TABLE_HEADING_METHOD   = 'Method';

const TEXT_ACTIONS_DIRECTORY = 'Actions Directory:';

const GET_HELP_LINK = 'https://phoenixcart.org/phoenixcartwiki/index.php?title=Actions';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_MONTHLY_SALES_TITLE = 'Monthly Sales Chart';
const MODULE_ADMIN_DASHBOARD_MONTHLY_SALES_DESCRIPTION = 'Show the monthly sales chart of the last X months';

const MODULE_ADMIN_DASHBOARD_MONTHLY_SALES_CHART_LINK = 'Monthly Sales';
const MODULE_ADMIN_DASHBOARD_MONTHLY_SALES_MONTHS_BUTTON = '%s Months';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_MODULES = '<i data-content="Modules" data-toggle="popover" data-placement="left" class="fas fa-folder-open fa-fw mr-1"></i><span class="d-inline d-md-none">Modules</span>';

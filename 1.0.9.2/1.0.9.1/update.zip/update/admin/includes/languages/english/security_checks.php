<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2022 Phoenix Cart

  Released under the GNU General Public License
*/

const HEADING_TITLE = 'Security Checks';

const TABLE_HEADING_TITLE = 'Title';
const TABLE_HEADING_MODULE = 'Module';
const TABLE_HEADING_INFO = 'Info';

const BUTTON_TEXT_RELOAD = 'Reload';

const GET_HELP_LINK = 'https://phoenixcart.org/phoenixcartwiki/index.php?title=Security_Checks';

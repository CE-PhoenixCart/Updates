<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const BOX_HEADING_REPORTS = '<i data-content="Reports" data-toggle="popover" data-placement="left" class="fas fa-chart-bar fa-fw mr-1"></i><span class="d-inline d-md-none">Reports</span>';

<div class="<?= MODULE_CONTENT_FORGOT_PASSWORD_CONTENT_WIDTH ?> cm-forgot-password">
  
  <?= new Button(MODULE_CONTENT_FORGOT_PASSWORD_INTRO_TEXT, 'fas fa-unlock-alt', 'btn-light', [], $GLOBALS['Linker']->build('password_forgotten.php')) ?>

</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

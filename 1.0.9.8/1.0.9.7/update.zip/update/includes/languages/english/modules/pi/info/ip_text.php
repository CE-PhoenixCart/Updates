<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const IP_TEXT_TITLE         = 'Text';
  const IP_TEXT_DESCRIPTION   = 'Shows the Page Text on the Info Page.<div class="alert alert-info">This is a child module for use with the &pi; system.</div>';

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_I_MODULAR_TITLE        = '&pi; Modular index';
  const MODULE_CONTENT_I_MODULAR_DESCRIPTION  = 'Now you can more easily layout your Index Page.<div class="alert alert-warning">This module requires the use of &pi; child modules.  Any slots that have no child modules...will not display!</div>';

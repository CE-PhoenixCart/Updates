<div class="<?= I_HERO_CONTENT_WIDTH ?> i-hero">

  <div class="mt-2 py-4 text-center bg-light">
    <?= I_HERO_TEXT ?>
    <div class="d-inline-flex">
      <?= sprintf(I_HERO_BUTTONS, $GLOBALS['Linker']->build('testimonials.php')); ?>
    </div>
  </div>
  
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

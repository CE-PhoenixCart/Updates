<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<tr>
  <td colspan="<?= $colspan ?? 1 ?>"><?= $output['title'] ?>
  <td class="text-end"><?= $output['text'] ?></td>
</tr>

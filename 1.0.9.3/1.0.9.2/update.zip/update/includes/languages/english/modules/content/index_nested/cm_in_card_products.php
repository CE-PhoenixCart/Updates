<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_IN_CARD_PRODUCTS_TITLE       = 'Latest Products';
  const MODULE_CONTENT_IN_CARD_PRODUCTS_DESCRIPTION = 'Shows the "Latest Products" module on your Index page.';

  const MODULE_CONTENT_IN_CARD_PRODUCTS_HEADING     = 'Latest Products';

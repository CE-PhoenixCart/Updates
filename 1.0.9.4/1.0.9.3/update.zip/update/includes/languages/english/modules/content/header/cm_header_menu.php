<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_HEADER_MENU_TITLE = 'Horizontal Menu';
  const MODULE_CONTENT_HEADER_MENU_DESCRIPTION = 'Adds Horizontal Menu (plus one layer) into the Header.';

  const MODULE_CONTENT_HEADER_MENU_TOGGLER = 'Toggle Menu';

  const MODULE_CONTENT_HEADER_MENU_MANUFACTURER_DROPDOWN = 'Manufacturers';

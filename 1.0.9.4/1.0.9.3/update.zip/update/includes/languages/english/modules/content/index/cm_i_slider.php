<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2024 Phoenix Cart

  Released under the GNU General Public License
*/

  const MODULE_CONTENT_I_SLIDER_TITLE         = 'Carousel';
  const MODULE_CONTENT_I_SLIDER_DESCRIPTION   = 'Shows a series of slides as a Carousel.  Links into the core advert_manager.';

  const MODULE_CONTENT_I_SLIDER_CONTROLS_PREV = 'Previous';
  const MODULE_CONTENT_I_SLIDER_CONTROLS_NEXT = 'Next';

<div class="<?= MODULE_CONTENT_PI_DATE_AVAILABLE_CONTENT_WIDTH ?> cm-pi-date-available">
  <ul class="list-group">
    <li class="list-group-item d-flex justify-content-between align-items-center">
      <?= sprintf(MODULE_CONTENT_PI_DATE_AVAILABLE_TEXT, $date) ?>
    </li>
  </ul>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

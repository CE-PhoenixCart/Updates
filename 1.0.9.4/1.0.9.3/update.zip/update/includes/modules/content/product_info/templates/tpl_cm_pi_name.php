<div class="<?= MODULE_CONTENT_PI_NAME_CONTENT_WIDTH ?> cm-pi-name">
  <h1 class="display-4"><?= sprintf(MODULE_CONTENT_PI_NAME_DISPLAY_NAME, $GLOBALS['product']->get('name')) ?></h1>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<div class="<?= MODULE_CONTENT_FOOTER_EXTRA_COPYRIGHT_CONTENT_WIDTH ?> cm-footer-extra-copyright">
  <?= sprintf(FOOTER_TEXT_BODY, date('Y'), $GLOBALS['Linker']->build('index.php'), STORE_NAME) ?>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<div class="<?= MODULE_CONTENT_CAS_TITLE_CONTENT_WIDTH ?> cm-cas-title">
  <h1 class="display-4"><?= MODULE_CONTENT_CAS_TITLE_PUBLIC_TITLE ?></h1>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

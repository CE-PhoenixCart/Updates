<div class="<?= MODULE_CONTENT_PINF_MESSAGE_CONTENT_WIDTH ?> cm-pinf-message">
  <div class="alert alert-danger" role="alert">
    <?= MODULE_CONTENT_PINF_MESSAGE_PRODUCT_NOT_FOUND ?>
  </div>
</div>

<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/
?>

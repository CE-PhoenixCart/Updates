<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const NAVBAR_TITLE_1 = 'My Account';
const NAVBAR_TITLE_2 = 'Data Privacy';

const HEADING_TITLE = 'What we know about you...';

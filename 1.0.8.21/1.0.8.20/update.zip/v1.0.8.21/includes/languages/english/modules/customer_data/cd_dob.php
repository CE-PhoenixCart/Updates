<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2023 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_CUSTOMER_DATA_DOB_TEXT_TITLE = 'Date of Birth';
const MODULE_CUSTOMER_DATA_DOB_TEXT_DESCRIPTION = 'Show a date of birth field in customer registration';

const ENTRY_DOB = 'Date of Birth';
const ENTRY_DOB_ERROR = 'Your Date of Birth seems to be incorrectly formatted.';

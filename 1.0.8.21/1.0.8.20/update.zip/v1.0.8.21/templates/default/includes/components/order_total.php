<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2023 Phoenix Cart

  Released under the GNU General Public License
*/
?>

<tr>
  <td><?= $output['title'] ?></td>
  <td class="text-right"><?= $output['text'] ?></td>
</tr>
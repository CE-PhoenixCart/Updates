<?php
/*
  $Id$

  CE Phoenix, E-Commerce made Easy
  https://phoenixcart.org

  Copyright (c) 2021 Phoenix Cart

  Released under the GNU General Public License
*/

const MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_TITLE = 'Certified Partners';
const MODULE_ADMIN_DASHBOARD_PHOENIX_ADDONS_DESCRIPTION = 'Show the latest offerings from Certified Partners';

const MODULE_ADMIN_DASHBOARD_PHOENIX_VIEW_ALL = 'View full list';
